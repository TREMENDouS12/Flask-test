import email
from msilib import RadioButtonGroup
from flask import Flask, render_template, request, url_for, redirect
import sqlite3

app=Flask(__name__, template_folder='template')




if __name__=='__main__':
   app.run()
